package Data;

import java.util.LinkedList;

public class Expresion {
    private LinkedList<Elemento> ElementosdeOperacion;
    public Expresion() {
        this.ElementosdeOperacion=new LinkedList<Elemento>();
    }
    public void reconocer(String expr){
        for (int i = 0; i < expr.length(); i++){
            char E = expr.charAt(i);
            if (E=='*'|| E=='+'||E=='-'||E=='/') {
                this.ElementosdeOperacion.add(new Operador(E));
            }
            else {

                this.ElementosdeOperacion.add(new Numero((float) Integer.parseInt(String.valueOf(E))));
            }
        }

    }
    public float Evaluar(){
        float resultado = 0.0F;
        try {
            while (1 != ElementosdeOperacion.size()) {
                Elemento N1 = ElementosdeOperacion.get(0);
                Elemento O = ElementosdeOperacion.get(1);
                Elemento N2 = ElementosdeOperacion.get(2);
                if (((Operador) O).getOp() == '+') {
                    resultado = ((Numero) N1).getN() + ((Numero) N2).getN();

                } else if (((Operador) O).getOp() == '*') {
                    resultado = ((Numero) N1).getN() * ((Numero) N2).getN();

                } else if (((Operador) O).getOp() == '/') {
                    try {
                        resultado = ((Numero) N1).getN() / ((Numero) N2).getN();

                    } catch (ArithmeticException e) {
                        System.out.println("Error no es una operacion valida: " + e.getMessage());
                    }


                } else if (((Operador) O).getOp() == '-') {
                    resultado = ((Numero) N1).getN() - ((Numero) N2).getN();

                }


                this.ElementosdeOperacion.remove();
                this.ElementosdeOperacion.remove();
                this.ElementosdeOperacion.remove();
                this.ElementosdeOperacion.add(0, new Numero(resultado));

            }
        }catch (IndexOutOfBoundsException e) {
        System.out.println("Error operacion incompleta: " );
       }

        return ((Numero)this.ElementosdeOperacion.get(0)).getN();

    }
    public void imprimirResultado(){

        System.out.println("Resultado= "+ElementosdeOperacion.get(0));


    }
}
