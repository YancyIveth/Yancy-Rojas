package Data;

public abstract class Elemento {
}
