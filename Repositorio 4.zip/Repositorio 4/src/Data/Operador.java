package Data;

public class Operador extends Elemento{
    private char op;

    public Operador(char op) {
        this.op = op;
    }

    public char getOp() {
        return op;
    }

    @Override
    public String toString() {
        return "Operador{" +
                "op=" + op +
                '}';
    }

    public void setOp(char op) {
        this.op = op;
    }
}
