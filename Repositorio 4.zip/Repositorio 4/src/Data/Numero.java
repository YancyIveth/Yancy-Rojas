package Data;

public class Numero extends Elemento{
    private Float N;

    public Numero(Float n) {
        this.N = n;
    }

    public Float getN() {
        return N;
    }

    public void setN(Float n) {
        N = n;
    }

    @Override
    public String toString() {
        return "Numero{" +
                "N=" + N +
                '}';
    }
}
