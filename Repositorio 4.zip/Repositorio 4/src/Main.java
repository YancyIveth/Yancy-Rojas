import Data.Expresion;

public class Main {
    public static void main(String[] args) {
        Expresion Expre = new Expresion();
        Expre.reconocer("2+8-5");
        Expre.Evaluar();
        Expre.imprimirResultado();

    }
}